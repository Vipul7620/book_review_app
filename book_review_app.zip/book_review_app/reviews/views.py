from django.shortcuts import render, redirect, get_object_or_404
from .models import BookReview
from .forms import BookReviewForm

def index(request):
    reviews = BookReview.objects.all()
    return render(request, 'reviews/index.html', {'reviews': reviews})

def detail(request, id):
    review = get_object_or_404(BookReview, id=id)
    return render(request, 'reviews/detail.html', {'review': review})

def create(request):
    if request.method == 'POST':
        form = BookReviewForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = BookReviewForm()
    return render(request, 'reviews/create.html', {'form': form})

def update(request, id):
    review = get_object_or_404(BookReview, id=id)
    if request.method == 'POST':
        form = BookReviewForm(request.POST, instance=review)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = BookReviewForm(instance=review)
    return render(request, 'reviews/update.html', {'form': form})

def delete(request, id):
    review = get_object_or_404(BookReview, id=id)
    if request.method == 'POST':
        review.delete()
        return redirect('index')
    return render(request, 'reviews/delete.html', {'review': review})
